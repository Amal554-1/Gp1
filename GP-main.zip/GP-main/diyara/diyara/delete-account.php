<?php
require 'auth_check.php';
require 'db.php';

$user_id = $_SESSION['user_id'];
$error = '';

/* CSRF token */
if (empty($_SESSION['csrf_delete'])) {
    $_SESSION['csrf_delete'] = bin2hex(random_bytes(32));
}

$stmt = $pdo->prepare('SELECT name, email, password, role FROM users WHERE user_id = ?');
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$user) {
    header('Location: logout.php');
    exit;
}

$is_admin = ($user['role'] === 'admin');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token    = $_POST['csrf'] ?? '';
    $password = $_POST['password'] ?? '';
    $confirm  = isset($_POST['confirm']);

    if ($is_admin) {
        $error = 'Admin accounts cannot be deleted from here.';
    } elseif (!hash_equals($_SESSION['csrf_delete'], $token)) {
        $error = 'Your session expired. Please try again.';
    } elseif ($password === '') {
        $error = 'Please enter your password to confirm.';
    } elseif (!$confirm) {
        $error = 'Please tick the confirmation box.';
    } elseif (!password_verify($password, $user['password'])) {
        $error = 'Incorrect password. Your account was not deleted.';
    } else {
        /* Deleting the user also deletes lifestyle/housing preferences (ON DELETE CASCADE) */
        $pdo->prepare('DELETE FROM users WHERE user_id = ?')->execute([$user_id]);

        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
        }
        session_destroy();
        header('Location: account-deleted.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Delete Account | Diyara</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&family=Playfair+Display:wght@500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="diyara.css?v=72">
<link rel="stylesheet" href="assets/css/danger.css?v=1">
</head>
<body class="page-edit-profile page-delete">

<header class="site-topbar">
    <div class="topbar-brand">
        <div class="topbar-logo-slot"></div>
        <div class="topbar-brand-text"><strong>Diyara</strong><span>Live where you belong.</span></div>
    </div>
    <nav class="topbar-nav">
        <a href="index.php" class="topbar-link">Home</a>
        <a href="recommendations.php" class="topbar-link">Recommendations</a>
        <a href="profile.php" class="topbar-link active">My Profile</a>
        <a href="logout.php" class="topbar-link">Logout</a>
    </nav>
</header>

<main class="page-body edit-pattern-page">
<div class="edit-pattern-grid">

<section class="edit-main-card">

    <div class="edit-intro">
        <div class="section-label"><span></span>ACCOUNT SETTINGS</div>
        <h1>Delete Account</h1>
        <p>This will permanently remove your Diyara account.</p>
    </div>

    <?php if ($error): ?>
    <div class="notification error-message">
        <div class="notification-icon">!</div>
        <div>
            <strong>Account not deleted</strong>
            <p><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
        </div>
    </div>
    <?php endif; ?>

    <div class="delete-warning">
        <strong>This action cannot be undone.</strong>
        The following will be permanently deleted:
        <ul>
            <li>Your account (<?= htmlspecialchars($user['email'], ENT_QUOTES, 'UTF-8') ?>)</li>
            <li>Your lifestyle preferences</li>
            <li>Your housing preferences</li>
        </ul>
    </div>

    <?php if ($is_admin): ?>
        <p>Admin accounts cannot be deleted from here.</p>
        <div class="form-actions"><a href="edit-profile.php" class="button cancel-button">Back</a></div>
    <?php else: ?>
    <form method="POST" class="edit-card" autocomplete="off">
        <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['csrf_delete'], ENT_QUOTES, 'UTF-8') ?>">

        <div class="input-group">
            <label for="password">Enter your password to confirm <span>*</span></label>
            <input type="password" id="password" name="password" placeholder="Your password" autocomplete="current-password" required>
        </div>

        <label class="confirm-check">
            <input type="checkbox" name="confirm" id="confirm" required>
            I understand that my account and data will be deleted permanently.
        </label>

        <div class="form-actions">
            <a href="edit-profile.php" class="button cancel-button">Cancel</a>
            <button type="submit" id="delBtn" class="btn-danger" disabled>Delete My Account</button>
        </div>
    </form>
    <script>
        var c = document.getElementById('confirm'), b = document.getElementById('delBtn');
        function sync() { b.disabled = !c.checked; }
        c.addEventListener('change', sync); sync();
    </script>
    <?php endif; ?>

</section>

<aside class="edit-pattern-side">
    <div class="edit-side-word">DIYARA<br>RIYADH</div>
    <div class="edit-side-copy">
        <span>DIYARA · ACCOUNT</span>
        <h3 dir="rtl">نبقى لك<br>متى ما رجعت.</h3>
    </div>
</aside>

</div>
</main>

<footer class="diyara-footer">
    <div class="footer-brand"><div class="footer-mark"></div><div><strong>Diyara</strong><span>Live where you belong.</span></div></div>
    <div class="footer-center"><strong dir="rtl">ديارٍ تشبهك، وحيٍّ يناسبك.</strong><span>Riyadh · Heritage · Future</span></div>
    <div class="footer-end"><span class="footer-line"></span><p>Riyadh, Saudi Arabia<br>© 2026 Diyara</p></div>
</footer>

</body>
</html>
