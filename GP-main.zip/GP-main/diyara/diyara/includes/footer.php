</main>

<footer class="diyara-footer">

    <div class="footer-brand">

        <div class="footer-mark"></div>

        <div>
            <strong>Diyara</strong>
            <span>Live where you belong.</span>
        </div>

    </div>


    <div class="footer-center">

        <strong dir="rtl">
            ديارٍ تشبهك، وحيٍّ يناسبك.
        </strong>

        <span>Riyadh · Heritage · Future</span>

    </div>


    <div class="footer-end">

        <span class="footer-line"></span>

        <p>
            Riyadh, Saudi Arabia
            <br>
            © 2026 Diyara
        </p>

    </div>

</footer>

</body>
</html>
